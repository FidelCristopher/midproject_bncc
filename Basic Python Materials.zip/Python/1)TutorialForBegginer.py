#This is my first Python program
print("Hello World")
print("I like pizza!")
print("It's really good!")