#Typecasting = the process of converting a variable from one data type to another str(), int(), float(), bool()

name = "Fidel"
age = 19
gpa = 3.9
is_student = True

print(type(name))

gpa = int(gpa)
print(gpa)

age = float(age)
print(age)

age = str(age)
print(age)
print(type(age))

name = bool(name)
print(name)